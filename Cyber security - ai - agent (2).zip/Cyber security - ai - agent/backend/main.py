from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from ai_service import analyze_incident

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Incident(BaseModel):
    incident: str

@app.post("/api/analyze")
def analyze(data: Incident):

    result = analyze_incident(data.incident)

    return {"analysis": result}


@app.get("/api/health")
def health():
    return {"status": "running"}