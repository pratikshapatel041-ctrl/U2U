def analyze_incident(text):

    if "failed login" in text.lower():
        return """
Attack Type: Brute Force

Severity: High

Recommendations:
- Block suspicious IP.
- Enable MFA.
- Reset compromised passwords.
"""

    elif "malware" in text.lower():
        return """
Attack Type: Malware Infection

Severity: High

Recommendations:
- Isolate affected system.
- Run antivirus scan.
- Remove malicious files.
"""

    else:
        return """
Attack Type: Unknown

Severity: Medium

Recommendations:
- Investigate manually.
"""