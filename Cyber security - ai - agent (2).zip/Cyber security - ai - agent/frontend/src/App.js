import React, { useState } from "react";
import "./App.css";

function App() {
  const [incident, setIncident] = useState("");
  const [response, setResponse] = useState("");
  const [loading, setLoading] = useState(false);

  const analyzeIncident = async () => {
    setLoading(true);

    const res = await fetch("http://localhost:8000/api/analyze", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        incident: incident,
      }),
    });

    const data = await res.json();

    setResponse(data.analysis);
    setLoading(false);
  };

  return (
    <div className="container">
      <h1>Cybersecurity Incident Response AI</h1>

      <textarea
        rows="10"
        placeholder="Paste security logs here..."
        value={incident}
        onChange={(e) => setIncident(e.target.value)}
      />

      <button onClick={analyzeIncident}>
        Analyze Incident
      </button>

      {loading && <p>Analyzing...</p>}

      {response && (
        <div className="result">
          <h2>Analysis</h2>
          <p>{response}</p>
        </div>
      )}
    </div>
  );
}

export default App;
